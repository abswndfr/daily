/*
 * Copyright (C) 2013-2014 Synopsys, Inc. All rights reserved.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __ASM_ARC_CONFIG_H_
#define __ASM_ARC_CONFIG_H_

#define CONFIG_SYS_BOOT_RAMDISK_HIGH

#define CONFIG_LMB

#endif /*__ASM_ARC_CONFIG_H_ */
