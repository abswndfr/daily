export J2SDKDIR=/usr/lib/jvm/java_jdk_8/jdk1.8.0_121
export J2REDIR=/usr/lib/jvm/java_jdk_8/jdk1.8.0_121/jre
export PATH=$PATH:/usr/lib/jvm/java_jdk_8/jdk1.8.0_121/bin:/usr/lib/jvm/java_jdk_8/jdk1.8.0_121/db/bin:/usr/lib/jvm/java_jdk_8/jdk1.8.0_121/jre/bin
export JAVA_HOME=/usr/lib/jvm/java_jdk_8/jdk1.8.0_121/
export DERBY_HOME=/usr/lib/jvm/java_jdk_8/jdk1.8.0_121/db